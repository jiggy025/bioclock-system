package UI.View.Panels;

import bioclock.dto.DeviceDTO;
import bioclock.dto.UserDataDTO;
import java.awt.Color;
import java.awt.Font;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class EmployeeDetailPanel extends JPanel {

    private JLabel nameLabel = new JLabel();
    private JLabel idLabel = new JLabel();
    private JLabel idNumLabel = new JLabel();
    private JLabel deviceLabel = new JLabel();
    private JLabel locationLabel = new JLabel();

    public EmployeeDetailPanel() {

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        setBackground(Color.WHITE);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        
        add(nameLabel);
        add(idLabel);
        add(idNumLabel);
        add(deviceLabel);
        add(locationLabel);

    }

    public void setEmployee(UserDataDTO emp) {
        
        System.out.println("Employee loaded: " + emp.getEmpName());
        nameLabel.setText(emp.getEmpName());
        idLabel.setText("Employee ID: " + emp.getEmpId());
        idNumLabel.setText("ID Number: " + emp.getEmpIdNum());
        deviceLabel.setText("Device: " + emp.getDeviceName());
        locationLabel.setText("Location: " + emp.getLocation());

    }

}